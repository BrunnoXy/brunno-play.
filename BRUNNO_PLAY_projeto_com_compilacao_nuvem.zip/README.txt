BRUNNO PLAY - projeto Android Studio (Android 15 / API 35)
Autoria: BrunnoSamp

Este é um aplicativo auxiliar com painel flutuante e rastreador manual.
Não injeta código no Gangstar Mirage, não lê memória do jogo e não inclui
Auto Farm, ESP ou Aimbot. Não há integração oficial comprovada para essas funções.

Como gerar o APK:
1. Abra a pasta do projeto no Android Studio.
2. Aguarde a sincronização do Gradle.
3. Selecione Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Instale o APK gerado em app/build/outputs/apk/debug/.

No Android 15, conceda a permissão "Exibir sobre outros apps" nas configurações
quando o aplicativo solicitar.
