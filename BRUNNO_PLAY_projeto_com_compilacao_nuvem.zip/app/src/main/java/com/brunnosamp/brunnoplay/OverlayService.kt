package com.brunnosamp.brunnoplay

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var panel: LinearLayout? = null
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (panel != null) return START_NOT_STICKY
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 14, 18, 14)
            setBackgroundColor(Color.rgb(22, 25, 35))
        }
        box.addView(TextView(this).apply {
            text = "BRUNNO PLAY  •  BRUNNOSAMP"
            textSize = 16f
            setTextColor(Color.GREEN)
        })
        box.addView(TextView(this).apply {
            text = "Rastreador de progresso\nXP atual: anote no jogo\nMissões: marque ao concluir"
            textSize = 14f
            setTextColor(Color.WHITE)
        })
        val close = Button(this).apply { text = "Fechar menu" }
        box.addView(close)
        close.setOnClickListener { stopSelf() }
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = 24; y = 120 }
        wm.addView(box, params)
        panel = box
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        panel?.let { wm.removeView(it) }
        panel = null
        super.onDestroy()
    }
}
