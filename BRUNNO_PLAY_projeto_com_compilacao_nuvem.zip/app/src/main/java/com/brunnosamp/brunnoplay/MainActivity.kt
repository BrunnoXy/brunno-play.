package com.brunnosamp.brunnoplay

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 40, 32, 32)
            setBackgroundColor(Color.rgb(18, 20, 28))
        }
        root.addView(TextView(this).apply {
            text = "BRUNNO PLAY\nGangstar Mirage • Android 15\n\nPainel auxiliar de missões e progresso"
            textSize = 22f
            setTextColor(Color.WHITE)
        })
        val button = Button(this).apply { text = "Ativar menu flutuante" }
        root.addView(button)
        button.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")))
            } else {
                startService(Intent(this, OverlayService::class.java))
                finish()
            }
        }
        root.addView(TextView(this).apply {
            text = "\nEste app acompanha informações inseridas manualmente. Não altera o jogo nem automatiza partidas."
            textSize = 14f
            setTextColor(Color.LTGRAY)
        })
        setContentView(root)
    }
}
